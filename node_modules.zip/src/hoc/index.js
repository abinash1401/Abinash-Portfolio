import SectionWrapper from "./SectionWrapper";

export { SectionWrapper };
